

```javascript
response_data = {
    checkout_url: 'https://sandbox.securepay.shurjopayment.com/spaycheckout/?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczpcL1wvc2FuZGJveC5zaHVyam9wYXltZW50LmNvbVwvYXBpXC9sb2dpbiIsImlhdCI6MTY0MjQ5NTk3MiwiZXhwIjoxNjQyNDk5NTcyLCJuYmYiOjE2NDI0OTU5NzIsImp0aSI6Im1JcEFrNHJPZ1h4TklWVG4iLCJzdWIiOjEsInBydiI6IjgwNWYzOWVlZmNjNjhhZmQ5ODI1YjQxMjI3ZGFkMGEwNzZjNDk3OTMifQ.k_RnbXwWIEc8_NiGgR3c3d0GQhASXv_fjK2S_Wz_Ksw&order_id=sp61e67fe5a7a17',
    amount: 500,
    currency: 'BDT',
    sp_order_id: 'sp61e67fe5a7a17',
    customer_order_id: 'aobws09sa800',
    customer_name: 'Minhajul Anwar',
    customer_address: '330 NIH BUT DHK',
    customer_city: 'Dhaka',
    customer_phone: '01534303074',
    customer_email: null,
    client_ip: 'unknown',
    intent: 'sale',
    transactionStatus: 'Initiated'
}

```
