# GetToken call (hidden) response

```javascript
{
  token: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczpcL1wvc2FuZGJveC5zaHVyam9wYXltZW50LmNvbVwvYXBpXC9sb2dpbiIsImlhdCI6MTY0Mzc4MjEwOSwiZXhwIjoxNjQzNzg1NzA5LCJuYmYiOjE2NDM3ODIxMDksImp0aSI6IjVOdGg2Qm9YbVU3VnRkbE4iLCJzdWIiOjEsInBydiI6IjgwNWYzOWVlZmNjNjhhZmQ5ODI1YjQxMjI3ZGFkMGEwNzZjNDk3OTMifQ.zWlTGrXYTbjiuKdepq9ZUVdQDPydJeBgLXWznknmiKo',
  store_id: 1,
  execute_url: 'https://sandbox.shurjopayment.com/api/secret-pay',
  token_type: 'Bearer',
  sp_code: '200',
  massage: 'Ok',
  TokenCreateTime: '2022-02-02 12:08:29pm',
  expires_in: 3600
}

```
