<?php
include 'functions.php';
Logout();
?>