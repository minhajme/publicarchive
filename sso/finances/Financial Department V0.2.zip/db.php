<?PHP
	$user_name = "";
	$password = "";
	$database = "";
	$server = "";
?>