<?php
$server=""; // write your website's ip here
$from = ""; //user will get their email from this address.
?>