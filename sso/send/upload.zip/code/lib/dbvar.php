<?php
		$database=""; //database name if needed add the prefix name
		$host=""; //Mysql server host
		$data_username=""; //database username
		$data_password=""; //database password
?>