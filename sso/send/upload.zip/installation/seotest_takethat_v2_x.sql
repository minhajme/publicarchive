-- phpMyAdmin SQL Dump
-- version 3.5.8.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 02, 2014 at 04:19 AM
-- Server version: 5.5.29
-- PHP Version: 5.3.20

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `seotest_takethat`
--

-- --------------------------------------------------------

--
-- Table structure for table `approval_log`
--

CREATE TABLE IF NOT EXISTS `approval_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(600) DEFAULT NULL,
  `notify_to` varchar(600) DEFAULT NULL,
  `who` varchar(600) DEFAULT NULL,
  `secret` varchar(150) DEFAULT NULL,
  `do_notify` tinyint(1) DEFAULT NULL,
  `status_notify` tinyint(1) DEFAULT NULL,
  `when_notify` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `approval_index1` (`file_name`(255)),
  KEY `approval_index2` (`secret`,`file_name`(255)),
  KEY `approval_index3` (`secret`,`file_name`(255),`who`(255),`notify_to`(255))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `blocked_users`
--

CREATE TABLE IF NOT EXISTS `blocked_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_user` varchar(120) DEFAULT NULL,
  `user_agent` text,
  `when_blocked` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `def_account`
--

CREATE TABLE IF NOT EXISTS `def_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxfiles` int(11) DEFAULT NULL,
  `maxsize` varchar(250) DEFAULT NULL,
  `maxrec` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `def_account`
--

INSERT INTO `def_account` (`id`, `maxfiles`, `maxsize`, `maxrec`) VALUES
(1, 1, '2002880', 1);

-- --------------------------------------------------------

--
-- Table structure for table `exclude_users`
--

CREATE TABLE IF NOT EXISTS `exclude_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email_address` varchar(600) DEFAULT NULL,
  `comment` text,
  `when_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `files_log`
--

CREATE TABLE IF NOT EXISTS `files_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group` varchar(100) DEFAULT NULL,
  `filename` varchar(600) DEFAULT NULL,
  `sender` varchar(600) DEFAULT NULL,
  `to` varchar(600) DEFAULT NULL,
  `notify` tinyint(1) DEFAULT NULL,
  `copy` tinyint(1) DEFAULT NULL,
  `user_ip` varchar(120) DEFAULT NULL,
  `user_agent` varchar(600) DEFAULT NULL,
  `message` text,
  `when_sent` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `file_type` varchar(100) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `log_index2` (`notify`,`filename`(255))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `install_manager`
--

CREATE TABLE IF NOT EXISTS `install_manager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `db_user` varchar(250) DEFAULT NULL,
  `db_password` varchar(250) DEFAULT NULL,
  `maxfiles` int(11) DEFAULT NULL,
  `maxfile_size` varchar(250) DEFAULT NULL,
  `maxrecipients` mediumint(9) DEFAULT NULL,
  `brand_name` varchar(250) DEFAULT NULL,
  `accept_types` text,
  `server_mail` varchar(250) DEFAULT NULL,
  `files_folder` varchar(450) DEFAULT NULL,
  `e_auto_title` text,
  `e_auto_body` text,
  `e_auto_title_copy` text,
  `e_auto_body_copy` text,
  `users_mode` varchar(14) DEFAULT NULL,
  `theme` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `install_manager`
--

INSERT INTO `install_manager` (`id`, `db_user`, `db_password`, `maxfiles`, `maxfile_size`, `maxrecipients`, `brand_name`, `accept_types`, `server_mail`, `files_folder`, `e_auto_title`, `e_auto_body`, `e_auto_title_copy`, `e_auto_body_copy`, `users_mode`, `theme`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 1, '2242880', 1, 'TakeThat v.2', '.doc,.docx,.log,.msg,.odt,.pages,.rtf,.tex,.txt,.wpd,.wps,.bmp,.dds,.gif,.jpg,.png,.psd,.pspimage,.tga,.thm,.tif,.tiff,.yuv', '', 'C:\\zpanel\\hostdata\\seotest\\public_html\\seotest_co_il\\proj\\filethat\\files\\', 'You received a File through TakeThat platform.', 'You are invited to use this amazing tool too.', 'This is a copy of the file(s) you sent through TakeThat platform.', '(Please DO NOT reply)', 'guests', 'silver');

-- --------------------------------------------------------

--
-- Table structure for table `users_manager`
--

CREATE TABLE IF NOT EXISTS `users_manager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(250) DEFAULT NULL,
  `password` varchar(250) DEFAULT NULL,
  `fullname` varchar(250) DEFAULT NULL,
  `maxfiles` int(11) DEFAULT NULL,
  `maxsize` varchar(250) DEFAULT NULL,
  `maxrec` int(11) DEFAULT NULL,
  `usermail` varchar(400) DEFAULT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `active` varchar(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_manager1` (`username`),
  KEY `users_manager2` (`active`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
