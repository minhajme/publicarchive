<?php
    error_reporting(0);
    @ini_set('display_errors', 'off');
    session_start();
    define('DS', DIRECTORY_SEPARATOR);
    
/******************************************************************************/
// Created by: shlomo hassid.
// Release Version : 2.1
// Creation Date: 12/09/2013
// Updated To V.2.1 : 05/01/2014
// Mail: Shlomohassid@gmail.com
// require: jquery latest version SQL 4+ PHP 5.3+ .	
// Copyright 2013, shlomo hassid.
/******************************************************************************/

// tockenize the page:
    if(!isset($_POST['get'])) 
        die('Unauthorized access! code:1'); 
    else 
        $token = $_POST['get'];
    
    if (!isset($_SESSION['user_token']) || $token != md5($_SESSION['user_token'])) { 
        die("Unauthorized access! code:2"); 
    }

    $debuger = array(
        'v_host'    => 	true,
        'v_db_user' =>  true,
        'v_db_pass' =>  true,
        'v_db_name' =>  true,
        'v_brand'   =>  true,
        'v_folder'  =>  true,
        'v_email'   =>  true,
        'v_maxsize'	=>  true,
        'v_maxfiles'=>  true,
        'v_maxrec'  =>  true,
        'v_user'    =>  true,
        'v_pass'    =>  true,
        'v_re_pass'	=>  true,
        'ch_connect_sql'             => true,
        'ch_connect_db'              => true,
        'ch_mysql_vers'              => true,
        'ch_writeable_files'         => true,
        'create_dbvar'	             => true,
        'ch_writeable_dbvar'         => true,
        'create_tables'	             => true,
        'insert_values_row_main'	 => true,
        'insert_values_row_daccount' => true
    );

/******************************************************************************/          
/****************************** FUNCTIONS: ************************************/
/******************************************************************************/
    //size calculation:
    function return_bytes($val) {
        
        if($val==-1||$val==false) $val = 2000000;
        
        $val = trim($val);
        $last = strtolower($val[strlen($val)-1]);
        switch($last) {
            case 'g':
                $val *= 1024;
            case 'm':
                $val *= 1024;
            case 'k':
                $val *= 1024;
        }
        return $val;
    }
    //create main settings table:
    function create_table_install_manager($database, $linkos) {
        $slq_query_check = "SELECT 1 FROM information_schema.tables WHERE ". 
                                "`table_schema` = '".$database."'". 
                                "AND `table_name` = 'install_manager';"; 
                                
        if(!mysqli_query($linkos, $slq_query_check)) { 
            return false; 
        } else { 
            $rs_result = mysqli_query($linkos, $slq_query_check); 
            $idr = mysqli_fetch_assoc($rs_result); }
            
            if (!isset($idr[1])) {
                $sql_query = "CREATE TABLE install_manager (
                            `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                            `db_user` VARCHAR(250) COLLATE utf8_general_ci,
                            `db_password` VARCHAR(250) COLLATE utf8_general_ci,
                            `maxfiles` INT(11) COLLATE utf8_general_ci,
                            `maxfile_size` VARCHAR(250) COLLATE utf8_general_ci,
                            `maxrecipients` MEDIUMINT(9),
                            `brand_name` VARCHAR(250) COLLATE utf8_general_ci,
                            `accept_types` TEXT COLLATE utf8_general_ci,
                            `server_mail` VARCHAR(250) COLLATE utf8_general_ci,
                            `files_folder` VARCHAR(450) COLLATE utf8_general_ci,
                            `e_auto_title` TEXT COLLATE utf8_general_ci,
                            `e_auto_body` TEXT COLLATE utf8_general_ci,
                            `e_auto_title_copy` TEXT COLLATE utf8_general_ci,
                            `e_auto_body_copy` TEXT COLLATE utf8_general_ci,
                            `users_mode` VARCHAR(14) COLLATE utf8_general_ci,
                            `theme` VARCHAR(50) COLLATE utf8_general_ci
                            )"; 
                                        
                if(!mysqli_query($linkos, $sql_query)) {  
                    return false; 
                } else {  
                    return true; 
                }
            } else {
                return true;
            }
    }
    //create def account table:
    function create_table_def_account($database, $linkos) {
        $slq_query_check = "SELECT 1 FROM information_schema.tables WHERE 
                            `table_schema` = '".$database."' 
                            AND `table_name` = 'def_account';
                            "; 
        if(!mysqli_query($linkos, $slq_query_check)) { 
            return false; 
        } else { 
            $rs_result = mysqli_query($linkos, $slq_query_check); 
            $idr = mysqli_fetch_assoc($rs_result); 
        }
        
        if (!isset($idr[1])) {
            $sql_query = "CREATE TABLE def_account (
                            `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                            `maxfiles` INT(11) COLLATE utf8_general_ci,
                            `maxsize` VARCHAR(250) COLLATE utf8_general_ci,
                            `maxrec` INT(11) COLLATE utf8_general_ci												
                        )";                                    
                if(!mysqli_query($linkos, $sql_query)) {  
                    return false; 
                } else {  
                    return true; 
                }
            } else {
                return true;
            }
    }
    //create users manager table:
    function create_table_users_manager($database, $linkos) {
        $slq_query_check = "SELECT 1 FROM information_schema.tables WHERE 
                            `table_schema` = '".$database."' 
                            AND `table_name` = 'users_manager';
                            "; 
        if(!mysqli_query($linkos, $slq_query_check)) { 
            return false; 
        } else { 
            $rs_result = mysqli_query($linkos, $slq_query_check); 
            $idr = mysqli_fetch_assoc($rs_result); 
        }
        
        if (!isset($idr[1])) {
            $sql_query = "CREATE TABLE users_manager (
                            `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                            `username` VARCHAR(250) COLLATE utf8_general_ci,
                            `password` VARCHAR(250) COLLATE utf8_general_ci,
                            `fullname` VARCHAR(250) COLLATE utf8_general_ci,
                            `maxfiles` INT(11) COLLATE utf8_general_ci,
                            `maxsize` VARCHAR(250) COLLATE utf8_general_ci,
                            `maxrec` INT(11) COLLATE utf8_general_ci,
                            `usermail` VARCHAR(400) COLLATE utf8_general_ci,
                            `added` TIMESTAMP DEFAULT NOW() ON UPDATE CURRENT_TIMESTAMP,
                            `active` VARCHAR(4) COLLATE utf8_general_ci                        
                        )"; 
                        
            $sql_query1 = "CREATE INDEX users_manager1 
                                ON users_manager (username)";
            $sql_query2 = "CREATE INDEX users_manager2
                                ON users_manager (active)";	
                      
            if(!mysqli_query($linkos, $sql_query)) {  
                return false; 
            } else { 
                if(!mysqli_query($linkos, $sql_query1)) {  }
                if(!mysqli_query($linkos, $sql_query2)) {  }
                return true; 
            }
            
            
        } else {
            return true;
        }
    }
    //create approval log table:
    function create_table_approval_log($database, $linkos) {
        $slq_query_check = "SELECT 1 FROM information_schema.tables WHERE 
                            `table_schema` = '".$database."'  
                            AND `table_name` = 'approval_log';
                            "; 
        if(!mysqli_query($linkos, $slq_query_check)) { 
            return false; 
        } else { 
            $rs_result = mysqli_query($linkos, $slq_query_check); 
            $idr = mysqli_fetch_assoc($rs_result); 
        }
        
        if (!isset($idr[1])) {
            $sql_query = "CREATE TABLE approval_log (
                             `id` BIGINT(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                            `file_name` VARCHAR(600) COLLATE utf8_general_ci,
                            `notify_to` VARCHAR(600) COLLATE utf8_general_ci,
                            `who` VARCHAR(600) COLLATE utf8_general_ci,
                            `secret` VARCHAR(150) COLLATE utf8_general_ci,
                            `do_notify` TINYINT(1),
                            `status_notify` TINYINT(1),
                            `when_notify` TIMESTAMP DEFAULT NOW() 
                                ON UPDATE CURRENT_TIMESTAMP												
                        )"; 
            $sql_query1 = "CREATE INDEX approval_index1 
                                ON approval_log (file_name)";
            $sql_query2 = "CREATE INDEX approval_index2 
                                ON approval_log (secret,file_name)";	
            $sql_query3 = "CREATE INDEX approval_index3 
                                ON approval_log (secret,file_name,who,notify_to)";	
                                    
            if(!mysqli_query($linkos, $sql_query)) {  
                return false; 
            } else { 
                if(!mysqli_query($linkos, $sql_query1)) {  }
                if(!mysqli_query($linkos, $sql_query2)) {  }
                if(!mysqli_query($linkos, $sql_query3)) {  }
                return true; 
            }
        } else {
            return true;
                                 }
    }
    //create files log table:
    function create_table_files_log($database, $linkos){
        $slq_query_check = "SELECT 1 FROM information_schema.tables WHERE 
                                        `table_schema` = '".$database."' AND 
                                        `table_name` = 'files_log';"; 
        
        if(!mysqli_query($linkos, $slq_query_check)) { 
            return false; 
        } else { 
            $rs_result = mysqli_query($linkos, $slq_query_check); 
            $idr = mysqli_fetch_assoc($rs_result); 
        }
        
        if (!isset($idr[1])) {
            $sql_query = "CREATE TABLE files_log (
                            `id` BIGINT(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                            `group` VARCHAR(100) COLLATE utf8_general_ci,
                            `filename` VARCHAR(600) COLLATE utf8_general_ci,
                            `sender` VARCHAR(600) COLLATE utf8_general_ci,
                            `to` VARCHAR(600) COLLATE utf8_general_ci,
                            `notify` TINYINT(1),
                            `copy` TINYINT(1),
                            `user_ip` VARCHAR(120) COLLATE utf8_general_ci,
                            `user_agent` VARCHAR(600) COLLATE utf8_general_ci,
                            `message` TEXT COLLATE utf8_general_ci,
                            `when_sent` TIMESTAMP DEFAULT NOW() 
                                ON UPDATE CURRENT_TIMESTAMP,
                            `file_type` VARCHAR(100) COLLATE utf8_general_ci,
                            `file_size` BIGINT(20)
                        )"; 
            $sql_query1 = "CREATE INDEX log_index1 ON files_log (group)";
            $sql_query2 = "CREATE INDEX log_index2 ON files_log (notify,filename)";	
                                        
            if(!mysqli_query($linkos, $sql_query)) {  
                return false; 
            } else { 
                if (!mysqli_query($linkos, $sql_query1)) {  }
                if (!mysqli_query($linkos, $sql_query2)) {  }
                return true; 
            }
        } else {
            return true;
        }
    }
    //create excluded users table:
    function create_table_exclude_users($database, $linkos){
        $slq_query_check = "SELECT 1 FROM information_schema.tables WHERE
                                `table_schema` = '".$database."' AND 
                                `table_name` = 'exclude_users';"; 
        if (!mysqli_query($linkos, $slq_query_check)) { 
            return false; 
        } else { 
            $rs_result = mysqli_query($linkos, $slq_query_check); 
            $idr = mysqli_fetch_assoc($rs_result); 
        }
        
        if (!isset($idr[1])) {								
            $sql_query = "CREATE TABLE exclude_users (
                             `id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
                            `email_address` VARCHAR(600) COLLATE utf8_general_ci,
                            `comment` TEXT COLLATE utf8_general_ci,
                            `when_added` TIMESTAMP DEFAULT NOW() 
                                ON UPDATE CURRENT_TIMESTAMP
                        )"; 
                                    
            if (!mysqli_query($linkos, $sql_query)) {  
                return false; 
            } else {  
                return true; 
            }

        } else {
            return true;
        }
    }
    //create blocked users table:
    function create_table_blocked_users($database, $linkos){
        $slq_query_check = "SELECT 1 FROM information_schema.tables WHERE 
                                `table_schema` = '".$database."' AND 
                                `table_name` = 'blocked_users';"; 
        
        if (!mysqli_query($linkos, $slq_query_check)) { 
            return false; 
        } else { 
            $rs_result = mysqli_query($linkos, $slq_query_check); 
            $idr = mysqli_fetch_assoc($rs_result); 
        }
        
        if (!isset($idr[1])) {	
            $sql_query = "CREATE TABLE blocked_users (
                             `id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
                            `ip_user` VARCHAR(120) COLLATE utf8_general_ci,
                            `user_agent` TEXT COLLATE utf8_general_ci,
                            `when_blocked` TIMESTAMP DEFAULT NOW() 
                                ON UPDATE CURRENT_TIMESTAMP
                        )"; 
                                    
            if (!mysqli_query($linkos, $sql_query)) {  
                return false; 
            } else {  
                return true; 
            }
        } else {
            return true;
        }
    }
    
/******************************************************************************/          
/****************************** SERVER VARS: **********************************/
/******************************************************************************/
    if(defined(__DIR__))																				define('DIRPATH', __DIR__);									else	define('DIRPATH',dirname(__FILE__));
    if(isset($_SERVER['HTTP_REFERER']))																	define('REF',$_SERVER['HTTP_REFERER']);						else	define('REF',false);
    if(isset($_SERVER['DOCUMENT_ROOT']))																define('DOCROOT', $_SERVER['DOCUMENT_ROOT']);				else	define('DOCROOT',false);
    if(isset($_SERVER['SERVER_NAME']))																	define('SERVERNAME', $_SERVER['SERVER_NAME']);				else	define('SERVERNAME',false);
    if(isset($_SERVER['HTTP_HOST']))																	define('SERVERHOST', $_SERVER['HTTP_HOST']);				else	define('SERVERHOST',false);
    if(isset($_SERVER['REMOTE_ADDR']))																	define('SERVERREMOTE', $_SERVER['REMOTE_ADDR']);			else	define('SERVERREMOTE',false);
    if(isset($_SERVER['HTTP_USER_AGENT']))																define('USERAGENT', $_SERVER['HTTP_USER_AGENT']);			else	define('USERAGENT',false);
    if(ini_get('max_file_uploads')!==false&&ini_get('max_file_uploads')!=null)							define('SYS_MAX_UPLOADS',ini_get('max_file_uploads'));		else	define('SYS_MAX_UPLOADS',false);
    if(ini_get('upload_max_filesize')!==false&&ini_get('upload_max_filesize')!=null)					define('SYS_MAX_FILESIZE',ini_get('upload_max_filesize'));	else	define('SYS_MAX_FILESIZE',false);
    if(ini_get('max_input_time')!==false&&ini_get('max_input_time')!=null)								define('SYS_MAX_INPUT_TIME',ini_get('max_input_time'));		else	define('SYS_MAX_INPUT_TIME',false);
    if(ini_get('max_input_vars')!==false&&ini_get('max_input_vars')!=null)								define('SYS_MAX_INPUT_VARS',ini_get('max_input_vars'));		else	define('SYS_MAX_INPUT_VARS',false);
    if(ini_get('file_uploads')!==false&&ini_get('file_uploads')!=null&&ini_get('file_uploads') == 1)	define('FILE_UPLOADS','YES');								else	define('FILE_UPLOADS','NO');
    if(ini_get('post_max_size')!==false&&ini_get('post_max_size')!=null)								define('SYS_MAX_POST_SIZE',ini_get('post_max_size'));		else	define('SYS_MAX_POST_SIZE',false);
        
/******************************************************************************/          
/******************************* VALIDATE: ************************************/
/******************************************************************************/
    // validate host:
    if (isset($_POST['host']) && $_POST['host']!='') 
        $mysql_host = mysql_escape_string($_POST['host']); 
    else 
        /*debuger*/ $debuger['v_host'] = false;
        
    // validate DB user:
    if (isset($_POST['db_user']) && $_POST['db_user']!='') 
        $data_username = mysql_escape_string($_POST['db_user']); 
    else 
        /*debuger*/ $debuger['v_db_user'] = false;
        
    // validate DB pass:
    if (isset($_POST['db_pass']) && $_POST['db_pass']!='') 
        $data_password = mysql_escape_string($_POST['db_pass']); 
    else 
        /*debuger*/ $debuger['v_db_pass'] = false;
        
    // validate DB name:
    if (isset($_POST['db_name']) && $_POST['db_name']!='') 
        $database_name = mysql_escape_string($_POST['db_name']); 
    else 
        /*debuger*/ $debuger['v_db_name'] = false;
        
    // validate File Path:
    if (isset($_POST['files_path']) 
        && file_exists($_POST['files_path'])
        && $_POST['files_path']!=''
    )
        $folder_path = $_POST['files_path']; 
    else 
        /*debuger*/ $debuger['v_folder'] = false;
        
    // validate Email:
    if (isset($_POST['email_account']) 
        && filter_var($_POST['email_account'], FILTER_VALIDATE_EMAIL)!==false
    ) 
        $email_server = $_POST['email_account']; 
    else	
        /*debuger*/ $debuger['v_email'] = false;
        
    // validate Max files upload: 
    if (isset($_POST['max_files']) 
        && $_POST['max_files']!='' 
        && is_numeric($_POST['max_files'])
    ) 
        $max_files_count = $_POST['max_files'];	
    else 	
        /*debuger*/ $debuger['v_maxfiles'] = false;
        
    if (isset($max_files_count)) 
        if($max_files_count>SYS_MAX_UPLOADS) 
            $max_files_count = SYS_MAX_UPLOADS;
    
    // validate Max file size:
    if (isset($_POST['max_size']) 
        && $_POST['max_size']!='' 
        && is_numeric($_POST['max_size'])
    ) 
        $max_file_size = $_POST['max_size']; 
    else 
        /* debuger */ $debuger['v_maxsize'] = false;
                
    if (isset($max_file_size)) 
        if($max_file_size>return_bytes(SYS_MAX_FILESIZE)) 
            $max_file_size = (return_bytes(SYS_MAX_FILESIZE) - 2000);	
    
    if (isset($max_file_size) 
        && isset($max_files_count) 
        && SYS_MAX_POST_SIZE!=false
        && SYS_MAX_POST_SIZE!=-1 
        &&($max_file_size*$max_files_count)>return_bytes(SYS_MAX_POST_SIZE)
    ) 
        $max_file_size = round((return_bytes(SYS_MAX_POST_SIZE)+1)/$max_files_count);
        
    // validate Max recipients:		
    if (isset($_POST['max_rec']) 
        && $_POST['max_rec']!='' 
        && is_numeric($_POST['max_rec'])
    ) 
        $max_rec = $_POST['max_rec']; 
    else 
        /* debuger */ $debuger['v_maxrec'] = false;
    
    if (isset($max_rec)) 
        if($max_rec>(SYS_MAX_INPUT_VARS-SYS_MAX_UPLOADS-6)) 
            $max_rec = (SYS_MAX_INPUT_VARS-SYS_MAX_UPLOADS-6);	
    
    // validate Admin user:
    if(isset($_POST['user']) 
        && $_POST['user']!='' 
        && strlen($_POST['user'])>4
    ) 
        $admin_user = $_POST['user']; 
    else 
        /* debuger */ $debuger['v_user'] = false;

    // validate Admin password:
    if(isset($_POST['pass']) 
        && $_POST['pass']!='' 
        && strlen($_POST['pass'])>5
    ) 
        $admin_pass = $_POST['pass']; 
    else 
        /* debuger */ $debuger['v_pass'] = false;

    // validate Admin re password:
    if (isset($_POST['repass']) && isset($admin_pass)) { 
        if ($admin_pass != $_POST['repass']) 
            /* debuger */ $debuger['v_re_pass'] = false;
    } else { 
        /* debuger */ $debuger['v_re_pass'] = false;	
    }	

    // validate Admin re password:
    if (isset($_POST['barnd_name']) && $_POST['barnd_name']!='') 
        $brand_name = $_POST['barnd_name']; 
    else 
        /* debuger */ $debuger['v_brand'] = false;			
    
    
// CHEK VALIDATION:
    foreach ($debuger as $key => $value) { 
        if(!$value) { 
            echo "val".json_encode($debuger); 
            die(); 
        }
    }

// CHECK FOR DB AND TEST CONNECTION:
    $linkos = @mysqli_connect("$mysql_host", "$data_username", "$data_password");
    if(!$linkos){ 
        /* debuger */ 
        $debuger['ch_connect_sql'] = false; 
        echo "val".json_encode($debuger); 
        die(); 
    } else {
        //using utf8 data
        mysqli_query($linkos, "SET NAMES 'utf8' COLLATE 'utf8_general_ci'");
        mysqli_set_charset($linkos, "utf8_general_ci");
        if (!mysqli_select_db($linkos, "$database_name")) {  
            /* debuger */ $debuger['ch_connect_db'] = false; 
            echo "val".json_encode($debuger); 
            die(); 
        }
    }
        
        
//CHECK SQL VERSION BIGGER THAN 4:
    $sql_version = @mysqli_get_server_info($linkos);
    if (!$sql_version) { 
        /* debuger */ 
        $debuger['ch_mysql_vers'] = false; 
        echo "val".json_encode($debuger); 
        die(); 
    } else {
        $sql_version = explode('.', $sql_version);
        if (intval($sql_version[0])<4) { 
            /* debuger */ 
            $debuger['ch_mysql_vers'] = false;
            echo "val".json_encode($debuger); 
            die(); 
        }
    }
        
// CHECK THAT FILES IS WRITEABLE:
    if (!is_writable($folder_path)) { 
        /* debuger */ 
        $debuger['ch_writeable_files'] = false;
        echo "val".json_encode($debuger); 
        die(); 
    }

/******************************************************************************/          
/****************************** PROCEDURES: ***********************************/
/******************************************************************************/

// UPDATE dbvar.php:
    if (file_exists('..'.DS.'code'.DS.'lib'.DS.'dbvar.php')) {
        if (!is_writable('..'.DS.'code'.DS.'lib'.DS.'dbvar.php')) { 
            /* debuger */ 
            $debuger['ch_writeable_dbvar'] = false; 
            echo "val".json_encode($debuger); 
            die(); 
        }	
        $f 	 = fopen('..'.DS.'code'.DS.'lib'.DS.'dbvar.php', "w+");
        $msg = utf8_encode("<?php\n\$database='".$database_name.
                           "';\n\$host='".$mysql_host."';\n\$data_username='".
                           $data_username."';\n\$data_password='".
                           $data_password."';\n?>"
        );
        
        if (fwrite($f, $msg) === FALSE) { 
            fclose($f); 
            /* debuger */ 
            $debuger['create_dbvar'] = false; 
            echo "val".json_encode($debuger); 
            die(); 
        }

        fclose($f);
            
    } else {
        /* debuge r*/ 
        $debuger['create_dbvar'] = false; 
        echo "val".json_encode($debuger); 
        die();
    }

// CREATE TABLES:
    if (!create_table_install_manager($database_name, $linkos)) { 
        /* debuger */ $debuger['create_tables'] = false; 
    }
    if (!create_table_def_account($database_name, $linkos)) { 
        /* debuger */ $debuger['create_tables'] = false; 
    }
    if (!create_table_users_manager($database_name, $linkos)) { 
        /* debuger */ $debuger['create_tables'] = false; 
    }
    if (!create_table_approval_log($database_name, $linkos)) { 
        /* debuger */ $debuger['create_tables'] = false; 
    }
    if (!create_table_files_log($database_name, $linkos)) { 
        /* debuger */ $debuger['create_tables'] = false; 
    }
    if (!create_table_exclude_users($database_name, $linkos)) { 
        /* debuger */ $debuger['create_tables'] = false; 
    }
    if (!create_table_blocked_users($database_name, $linkos)) { 
        /* debuger */ $debuger['create_tables'] = false; 
    }
        
    foreach ($debuger as $key => $value) { 
        if (!$value) { 
            echo "val".json_encode($debuger); 
            die(); 
        } 
    }
    
// CREATE Main row:

    $sqlstat= "INSERT INTO install_manager".
        "(`id`,".
        "`db_user`,".
        "`db_password`,".
        "`maxfiles`,".
        "`maxfile_size`,".
        "`maxrecipients`,".
        "`brand_name`,".
        "`accept_types`,".
        "`server_mail`,".
        "`files_folder`,".
        "`e_auto_title`,".
        "`e_auto_body`,".
        "`e_auto_title_copy`,".
        "`e_auto_body_copy`,".
        "`users_mode`,".
        "`theme`".
        ") VALUES (".
        "'1',".
        "'".mysqli_real_escape_string($linkos, $admin_user)."',".
        "'".mysqli_real_escape_string($linkos, md5($admin_pass))."',".
        "'".mysqli_real_escape_string($linkos, $max_files_count)."',".
        "'".mysqli_real_escape_string($linkos, $max_file_size)."',".
        "'".mysqli_real_escape_string($linkos, $max_rec)."',".
        "'".mysqli_real_escape_string($linkos, $brand_name)."',".
        "'".mysqli_real_escape_string($linkos, ".doc,.docx,.log,.msg,.odt".
                                                 ",.pages,.rtf,.tex,.txt,".
                                              ".wpd,.wps,.bmp,.dds,.gif,".
                                              ".jpg,.png,.psd,.pspimage,".
                                              ".tga,.thm,.tif,.tiff,.yuv"
                                            )."',".
        "'".mysqli_real_escape_string($linkos, $email_server)."',".
        "'".mysqli_real_escape_string($linkos, $folder_path)."',".
        "'".mysqli_real_escape_string($linkos, "You received a File through ".
                                                $brand_name." platform.")."',".
        "'".mysqli_real_escape_string($linkos, "You are invited to use this ".
                                                "amazing tool too.")."',".
        "'".mysqli_real_escape_string($linkos, "This is a copy of the file(s) ".
                                                "you sent through ".
                                                $brand_name." platform.")."',".
        "'".mysqli_real_escape_string($linkos, "(Please DO NOT reply to this email)")."',".
        "'".mysqli_real_escape_string($linkos, "guests")."',".
        "'".mysqli_real_escape_string($linkos, "silver")."')";
                                            
        if(!mysqli_real_query($linkos, $sqlstat)) { 
            /* debuger */ 
            $debuger['insert_values_row_main'] = false; 
            echo "val".json_encode($debuger); die(); 
        }
        
// CREATE DEF ACCOUNT:

    $sqlstat11= "INSERT INTO def_account".
        "(`id`,".
        "`maxfiles`,".
        "`maxsize`,".
        "`maxrec`".
        ") VALUES (".
        "'1',".
        "'".mysqli_real_escape_string($linkos, $max_files_count)."',".
        "'".mysqli_real_escape_string($linkos, $max_file_size)."',".
        "'".mysqli_real_escape_string($linkos, $max_rec)."')";
                                            
        if(!mysqli_real_query($linkos, $sqlstat11)) { 
            /* debuger */ 
            $debuger['insert_values_row_daccount'] = false; 
            echo "val".json_encode($debuger); die(); 
        } else {
            /* installation OK! */
            echo "OK!"; 
        }
        

?>