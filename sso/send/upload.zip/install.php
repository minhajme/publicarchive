<?php
    error_reporting(0);
    @ini_set('display_errors', 'off');
    session_start();
    define('DS', DIRECTORY_SEPARATOR);
    
/******************************************************************************/
// Created by: shlomo hassid.
// Release Version : 2.1
// Creation Date: 12/09/2013
// Updated To V.2.1 : 05/01/2014
// Mail: Shlomohassid@gmail.com
// require: jquery latest version SQL 4+ PHP 5.3+ .	
// Copyright 2013, shlomo hassid.
/******************************************************************************/


//tockenize the page:
if(!isset($_SESSION['user_token'])) 
    $_SESSION['user_token'] = uniqid();
    
$token = md5($_SESSION['user_token']);

?>
<!DOCTYPE html>
<html lang='en' xmlns='http://www.w3.org/1999/xhtml'>
<head>
    <meta charset="UTF-8" />
    <META http-equiv="Pragma" CONTENT="no-cache">
    <META http-equiv="Expires" CONTENT="-1">
    <meta http-equiv="X-UA-Compatible" content="chrome=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>TakeThat v2.1 - File Share installation Script</title>
    
    <script language="javascript" src="http://code.jquery.com/jquery-1.10.2.min.js" type="text/javascript"></script>

<style>
    body{
    font-size:14px;
    font-family: 'tahoma', 'arial' ,cursive;
    color:#2E2E2E;	
    background-image: url(img/back1.jpg);
    background-repeat: no-repeat;
    background-position: center center;
    background-attachment: fixed;	
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
    }	
    .header{
        margin:0 auto;
        width:800px;
        border:1px solid #BDBDBD;
        -moz-border-radius: 5px;
        -webkit-border-radius: 5px;
        border-radius:5px;
        padding:5px;
        background-color:#424242;
    }
    .header p{
        display:inline-block;
        float:right;
        font-weight:bold;
        margin:30px 20px 0px 0px;
        color:white;
    }
    .body_conn{
        margin:0 auto;
        padding:5px;
        width:800px;
        border:1px solid #BDBDBD;
        -moz-border-radius: 5px;
        -webkit-border-radius: 5px;
        border-radius:5px;	
    }
    p.steps{
        font-size:1.2em;
        font-weight:bold;
        margin:3px 5px 5px 0px;
        padding:2px;
        width:90%;
        background-color:#4AC692;
        -moz-border-radius:4px 25px 25px 4px;
        -webkit-border-radius:4px 25px 25px 4px;
        border-radius:4px 25px 25px 4px;
    }
    em {
        font-size:0.9em;
        font-weight:400;
        margin-left:15px;		
    }
    .help_conn,
    .erroe_conn{
        padding:5px;
        font-size:0.8em;
        background-color:#D6F2E6;
        border:1px solid #B7F1D9;
        width:600px;
    }
    .erroe_conn{
        background-color:#F6D8CE;
        border:1px solid #F79F81;
    }
    img.help_expand{
        opacity:0.5;
        cursor:pointer;
        width:20px;
        height:20px;
        margin:3px 8px 0px 5px;
    }
    img.help_expand:hover{
        opacity:1;
    }
input[type="text"],
input[type="password"],
.css-textarea{
    padding: 5px;   
    border: 1px solid #DDDDDD;
    outline: none;  
    width:95%;
    background: -moz-linear-gradient(center top , #FFFFFF,  #EEEEEE 1px, #FFFFFF 20px);    
    background: -webkit-linear-gradient(top, #EEEEEE 0%, #FFFFFF 100%);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#FBFBFB', endColorstr='#FFFFFF');   
    -moz-border-radius: 10px;
    -webkit-border-radius: 10px;
    border-radius: 10px;
    -moz-box-shadow: 0 0 2px #DDDDDD;
    -webkit-box-shadow: 0 0 2px #DDDDDD;
    box-shadow: 0 0 2px #DDDDDD;
        -webkit-user-modify: read-write-plaintext-only;
        -webkit-tap-highlight-color: rgba(255,255,255,0);
}

input[type="text"]:hover,
input[type="password"]:hover,
.css-textarea:hover{
    border:1px solid #FACC2E;
}
input[type="text"]:focus,
input[type="password"]:focus,
.css-textarea:focus{
    -webkit-box-shadow: 0px 0px 5px 0px #FACC2E;
    -moz-box-shadow: 0px 0px 5px 0px #FACC2E;
    box-shadow:0px 0px 5px 0px #FACC2E;
}
.css-textarea{
    resize:vertical;
    -moz-border-radius: 5px !important;
    -webkit-border-radius: 5px !important;
    border-radius: 5px !important;
}
.classtd_explain{
    background-color:#E6E6E6;
    width:340px !important;
}
.error_val{
    padding:5px;
    color:red;
    background-color:#F8E6E0;
    -moz-border-radius:10px;
    -webkit-border-radius:10px;
    border-radius:10px;
        -webkit-transition: 0.4s;
        -moz-transition: 0.4s;
        -ms-transition: 0.4s;
        -o-transition: 0.4s;
        transition: 0.4s;
}
div#mess_conn{
    position:absolute;
    top:0;
    left:0;
    z-index:900;
    width:100%;
    height:100%;
    padding-top:200px;
}
div#mess_text{
    margin:0 auto;
    width:550px;
    height:270px;
    background-color:#E6E6E6;
    -moz-border-radius: 20px;
    -webkit-border-radius: 20px;
    border-radius:20px;
    padding:30px;
    border:2px solid #0B173B;
    font-size:1.1em;
}
img.hide_done,
img.hide_mess,
img.hide_errors{
    float:right;
    cursor:pointer;
    opacity:0.6;
    -webkit-transition: 0.2s;
    -moz-transition: 0.2s;
    -ms-transition: 0.2s ;
    -o-transition: 0.2s;
    transition: 0.2s;
}
img.hide_done:hover,
img.hide_mess:hover,
img.hide_errors:hover{
    opacity:1;
}
.run_in{
    margin-left:300px;
    margin-top:10px;
    width:180px; 
    height:30px;
    font-weight:bold;
    cursor:pointer;
}
</style>
<script type="text/javascript">
$(document).ready(function(){
        //Expand Help:
        $('.help_expand').click(function(){ $(this).closest('tr').next('tr').find('div.help_conn').eq(0).slideToggle(); });

        //hide done inline message:
        $(document).on('click','.hide_done',function(){ $(this).parent('div').slideUp('slow'); });		

        //hide done popup message:
        $(document).on('click','.hide_mess',function(){ $('div#mess_text').empty().parent('div').fadeOut(800); });		
        
        //run install:
        $('#run_install').click(function(){
                var dataform = $("form#install_fom").serialize();
                $.ajax({
                    url: 'installation/create_all_needed.php',  //Server script to process data
                    type: 'POST',
                    data: dataform,
                    beforeSend: function(){
                        $('div#mess_text').empty();
                        $('.erroe_conn').empty().slideUp('fast');
                        $('.remove1').removeClass('error_val');
                    },
                    success: function(response){
                        
                        switch(response.substring(0,3)){
                            case 'OK!': 
                                        $('div#mess_text').html('<img src="installation/no.png" class="hide_mess" /><b>Installation Done!</b><br />The platform was installed succesfully. <br />You should delete installation file and directory! <br />Running this installation again will override the current installation. <br />You can update settings via Admin Panel and many more - check it out later.').parent('div').fadeIn(500);
                                        break;
                            case 'una': 
                                        $('div#mess_text').html('<img src="installation/no.png" class="hide_mess" /><b>Installation Problem!</b><br />This is a security error, it may happen due to browser compabillity or server compabillity.').parent('div').fadeIn(500);
                                        break;
                            case 'val': var object_val = $.parseJSON(response.substring(3));
                                        $.each(object_val, function(index, value) { if(!value){
                                                switch(index){
                                                    case 'v_db_name':
                                                        $('#er_dbname').addClass('error_val');
                                                        $('#er_dbname').closest('tr').next('tr').find('div.erroe_conn').eq(0).html('You have to enter a full database name that you created for this installation. <img src="installation/eye.png" class="hide_done" width="16px" height="14px" />').slideDown();
                                                        break;
                                                    case 'v_db_pass':
                                                        $('#er_dbpass').addClass('error_val');
                                                        $('#er_dbpass').closest('tr').next('tr').find('div.erroe_conn').eq(0).html('You have to enter the database password.<img src="installation/eye.png" class="hide_done" width="16px" height="14px" />').slideDown();
                                                        break;	
                                                    case 'v_db_user':
                                                        $('#er_dbuser').addClass('error_val');
                                                        $('#er_dbuser').closest('tr').next('tr').find('div.erroe_conn').eq(0).html('You have to enter the database username.<img src="installation/eye.png" class="hide_done" width="16px" height="14px" />').slideDown();
                                                        break;
                                                    case 'v_email':
                                                        $('#er_email').addClass('error_val');
                                                        $('#er_email').closest('tr').next('tr').find('div.erroe_conn').eq(0).html('You have to enter a Valid e-mail address that is set as a email account in your server.<img src="installation/eye.png" class="hide_done" width="16px" height="14px" />').slideDown();
                                                        break;	
                                                    case 'v_folder':
                                                        $('#er_folder').addClass('error_val');
                                                        $('#er_folder').closest('tr').next('tr').find('div.erroe_conn').eq(0).html('The folder path you typed is incorrect or invalid, no such directory found on server.<img src="installation/eye.png" class="hide_done" width="16px" height="14px" />').slideDown();
                                                        break;
                                                    case 'v_host':
                                                        $('#er_host').addClass('error_val');
                                                        $('#er_host').closest('tr').next('tr').find('div.erroe_conn').eq(0).html('You have to enter a Valid host name of the mySql server - Normaly "localhost" will do the trick.<img src="installation/eye.png" class="hide_done" width="16px" height="14px" />').slideDown();
                                                        break;	
                                                    case 'v_brand':
                                                        $('#er_brand').addClass('error_val');
                                                        $('#er_brand').closest('tr').next('tr').find('div.erroe_conn').eq(0).html('You have to enter a you brand name - If you are not sure just type "TakeThat",<br /> you will be able to edit this from the admin pannel too.<img src="installation/eye.png" class="hide_done" width="16px" height="14px" />').slideDown();
                                                        break;
                                                    case 'v_maxfiles':
                                                        $('#er_maxfile').addClass('error_val');
                                                        $('#er_maxfile').closest('tr').next('tr').find('div.erroe_conn').eq(0).html('You have to enter an upload file limit. This must be a numeric value and will be set to server limit if you overcome it.<img src="installation/eye.png" class="hide_done" width="16px" height="14px" />').slideDown();
                                                        break;
                                                    case 'v_maxrec':
                                                        $('#er_maxrec').addClass('error_val');
                                                        $('#er_maxrec').closest('tr').next('tr').find('div.erroe_conn').eq(0).html('You have to enter a recipients limit. This must be a numeric value and will be set to server limit if you overcome it.<img src="installation/eye.png" class="hide_done" width="16px" height="14px" />').slideDown();
                                                        break;	
                                                    case 'v_maxsize':
                                                        $('#er_maxsize').addClass('error_val');
                                                        $('#er_maxsize').closest('tr').next('tr').find('div.erroe_conn').eq(0).html('You have to enter an upload size limit. <br />This must be a numeric value (bytes) and will be set to server limit if you overcome it.<br /> Please consider the upload time limit of the server when setting this value.<img src="installation/eye.png" class="hide_done" width="16px" height="14px" />').slideDown();
                                                        break;
                                                    case 'v_pass':
                                                        $('#er_pass').addClass('error_val');
                                                        $('#er_pass').closest('tr').next('tr').find('div.erroe_conn').eq(0).html('Admin password must be at least 6 chars long.<img src="installation/eye.png" class="hide_done" width="16px" height="14px" />').slideDown();
                                                        break;	
                                                    case 'v_re_pass':
                                                        $('#er_repass').addClass('error_val');
                                                        $('#er_repass').closest('tr').next('tr').find('div.erroe_conn').eq(0).html('Passwords don\'t match!<img src="installation/eye.png" class="hide_done" width="16px" height="14px" />').slideDown();
                                                        break;
                                                    case 'v_user':
                                                        $('#er_user').addClass('error_val');
                                                        $('#er_user').closest('tr').next('tr').find('div.erroe_conn').eq(0).html('Admin user name must be at least 5 chars long.<img src="installation/eye.png" class="hide_done" width="16px" height="14px" />').slideDown();
                                                        break;	
                                                    case 'ch_connect_db':
                                                        
                                                        $('#er_dbname').addClass('error_val');											
                                                            $('div#mess_text').html('<img src="installation/no.png" class="hide_mess" /><b>Installation Problem!</b><br />Could not connect to DataBase, please check your DataBase name then run the installation again. <br /> If your server uses prefix database names (domain_database) please type the name with the correct prefix.').parent('div').fadeIn(500);;
                                                        break;
                                                    case 'ch_connect_sql':
                                                        $('#er_host').addClass('error_val');
                                                        $('#er_dbuser').addClass('error_val');
                                                        $('#er_dbpass').addClass('error_val');
                                                            $('div#mess_text').html('<img src="installation/no.png" class="hide_mess" /><b>Installation Problem!</b><br />Could not connect to mysql server, please check your Host and user-name/password then run the installation again.').parent('div').fadeIn(500);
                                                        break;	
                                                    case 'ch_mysql_vers':
                                                            $('div#mess_text').html('<img src="installation/no.png" class="hide_mess" /><b>Installation Problem!</b><br />Cannot install this website - Mysql version is too old, must be at leas 4 or newer. <br />Please upgrade and try again.').parent('div').fadeIn(500);													
                                                        break;
                                                    case 'ch_writeable_dbvar':
                                                            $('div#mess_text').html('<img src="installation/no.png" class="hide_mess" /><b>Installation Problem!</b><br />Cannot find file: "code/lib/dbvar.php" this file is required and need to be writeable!').parent('div').fadeIn(500);
                                                        break;	
                                                    case 'ch_writeable_files':
                                                            $('div#mess_text').html('<img src="installation/no.png" class="hide_mess" /><b>Installation Problem!</b><br />Files folder is not writable: Please make it writeable and launch installation again.').parent('div').fadeIn(500);
                                                        break;
                                                    case 'create_dbvar':
                                                            $('div#mess_text').html('<img src="installation/no.png" class="hide_mess" /><b>Installation Problem!</b><br />Cannot write to: "code/lib/dbvar.php" this file is required and need to be writeable!<br />Please make it writeable and launch installation again.').parent('div').fadeIn(500);
                                                        break;	
                                                    case 'create_tables':
                                                            $('div#mess_text').html('<img src="installation/no.png" class="hide_mess" /><b>Installation Problem!</b><br />Cannot create database tables: make sure SQL "CREATE TABLE" queries are not disabled <br />by the server then run installation again. <br />If you can\'t get it to work check documentation for manual installation.').parent('div').fadeIn(500);
                                                        break;
                                                    case 'insert_values_row_main':
                                                            $('div#mess_text').html('<img src="installation/no.png" class="hide_mess" /><b>Installation Problem!</b><br />Main settings couldn\'t be saved to database. This is rare and shouldnn\'t happen! Go to documentation and follow the manual installation.').parent('div').fadeIn(500);
                                                        break;	
                                                    case 'insert_values_row_daccount':
                                                            $('div#mess_text').html('<img src="installation/no.png" class="hide_mess" /><b>Installation Problem!</b><br />Main settings couldn\'t be saved to database. This is rare and shouldnn\'t happen! Go to documentation and follow the manual installation.').parent('div').fadeIn(500);
                                                        break;	                                                        
                                                    default: $('div#mess_text').html('<img src="installation/no.png" class="hide_mess" /><b>Installation Problem!</b><br />An unknown error occurred! Try again and make sure MySQL server is available, if it happens again go to documentation<br /> and follow manual installation guide.').parent('div').fadeIn(500);
                                                                
                                                }
                                        }
                                        });
                                        
                                        break;
                            default: $('div#mess_text').html('<img src="installation/no.png" class="hide_mess" /><b>Installation Problem!</b><br />An unknown error occurred! Try again and make sure MySQL server is available, if it happens again go to documentation<br /> and follow manual installation guide.').parent('div').fadeIn(500);
                        }
                    },
                    error: function(xhr, ajaxOptions, thrownError){
                        $('div#mess_text').html('<img src="installation/no.png" class="hide_mess" /><b>Installation Problem!</b><br />An unknown error occurred! Try again and make sure MySQL server is available, if it happens again go to documentation<br /> and follow manual installation guide.').parent('div').fadeIn(500);
                    }
                });		
        
        
        });
});
</script>
</head>
<body>

<div id='mess_conn' style='display:none;'>
    <div id='mess_text'>zxc</div>
</div>

<div class='header'>
    <img src="img/takethatlogo.png" />
    <p>Quick Installation File - v2.1</p>
</div>

<div class='body_conn'>
    <form name='install_fom' id='install_fom'>
        <input type='hidden' name='get' id='get' value='<?php echo md5($_SESSION['user_token']); ?>' />
        <p class='steps'>Server Configuration Test:<em>Server Settings.</em></p>
<?php
    if(defined(__DIR__))																				define('DIRPATH', __DIR__);									else	define('DIRPATH',dirname(__FILE__));
    if(isset($_SERVER['HTTP_REFERER']))																	define('REF',$_SERVER['HTTP_REFERER']);						else	define('REF',false);
    if(isset($_SERVER['DOCUMENT_ROOT']))																define('DOCROOT', $_SERVER['DOCUMENT_ROOT']);				else	define('DOCROOT',false);
    if(isset($_SERVER['SERVER_NAME']))																	define('SERVERNAME', $_SERVER['SERVER_NAME']);				else	define('SERVERNAME',false);
    if(isset($_SERVER['HTTP_HOST']))																	define('SERVERHOST', $_SERVER['HTTP_HOST']);				else	define('SERVERHOST',false);
    if(isset($_SERVER['REMOTE_ADDR']))																	define('SERVERREMOTE', $_SERVER['REMOTE_ADDR']);			else	define('SERVERREMOTE',false);
    if(isset($_SERVER['HTTP_USER_AGENT']))																define('USERAGENT', $_SERVER['HTTP_USER_AGENT']);			else	define('USERAGENT',false);
    if(ini_get('max_file_uploads')!==false&&ini_get('max_file_uploads')!=null)							define('SYS_MAX_UPLOADS',ini_get('max_file_uploads'));		else	define('SYS_MAX_UPLOADS',false);
    if(ini_get('upload_max_filesize')!==false&&ini_get('upload_max_filesize')!=null)					define('SYS_MAX_FILESIZE',ini_get('upload_max_filesize'));	else	define('SYS_MAX_FILESIZE',false);
    if(ini_get('max_input_time')!==false&&ini_get('max_input_time')!=null)								define('SYS_MAX_INPUT_TIME',ini_get('max_input_time'));		else	define('SYS_MAX_INPUT_TIME',false);
    if(ini_get('max_input_vars')!==false&&ini_get('max_input_vars')!=null)								define('SYS_MAX_INPUT_VARS',ini_get('max_input_vars'));		else	define('SYS_MAX_INPUT_VARS',false);
    if(ini_get('file_uploads')!==false&&ini_get('file_uploads')!=null&&ini_get('file_uploads') == 1)	define('FILE_UPLOADS','YES');								else	define('FILE_UPLOADS','NO');
    if(ini_get('post_max_size')!==false&&ini_get('post_max_size')!=null)								define('SYS_MAX_POST_SIZE',ini_get('post_max_size'));		else	define('SYS_MAX_POST_SIZE',false);
        
    //check for disabled functions:
    $required_func = array(
        'fopen',
        'fwrite',
        'unlink',
        'mail',
        'uniqid',
        'ini_get',
        'move_uploaded_file',
        'file_exists',
        'filesize',
        'scandir',
        'unlink',
        'mail',
        'filter_var',
        'parse_url',
        'array_diff',
        'array_key_exists',
        'date_create_from_format',
        'json_encode',
        'ucfirst',
        'number_format',
        'defined',
        'in_array',
        'is_numeric',
        'strtotime',
        'setcookie'
    );
    $func_dis 	= explode(', ', ini_get('disable_functions'));
    $flag_func 	= true;
    $functions_to_turn_on = '<br />Functions to enable:<br />';

    if(!DOCROOT) { 
        $flag_func = false; 
        $functions_to_turn_on .= "\$_SERVER['DOCUMENT_ROOT'] - "; 
    }
    if(!SERVERNAME) { 
        $flag_func = false; 
        $functions_to_turn_on .= "\$_SERVER['SERVER_NAME'] - "; 
    }
    if(!SERVERHOST) { 
        $flag_func = false; 
        $functions_to_turn_on .= "\$_SERVER['HTTP_HOST'] - "; 
    }
            
    //disable functions:
    foreach($func_dis as $value) { 
        if (in_array($value, $required_func)) { 
            $functions_to_turn_on .= $value.' - '; 
            $flag_func = false; 
        } 
    }
    
    //check functions exists:
    foreach ($required_func as $value) { 
        if (!function_exists($value)) { 
            $functions_to_turn_on .= $value.' - '; 
            $flag_func = false; 
        } 
    }
            
    if (!$flag_func) { 
        $required_func_icon="<img src='installation/no.png' class='help_expand' />"; 
        $inline_mes_func='Check Help!'; 
    } else { 
        $required_func_icon = "<img src='installation/yes.png' class='help_expand' />"; 
        $inline_mes_func='OK!'; 
    }
             
    //suggest:
    $filesfolder = DIRPATH.DS."files".DS;
    $php_version = phpversion();
            
    if (!SYS_MAX_UPLOADS) { 
        $maxfiles_s = 'Server "max_file_uploads" not available'; 
        $maxfiles = 3; 
    } else { 
        $maxfiles_s = SYS_MAX_UPLOADS; 
        if (SYS_MAX_UPLOADS<3 && SYS_MAX_UPLOADS>0) 
            $maxfiles = SYS_MAX_UPLOADS; else $maxfiles = 3; 
    }
    
    if (!SYS_MAX_FILESIZE) { 
        $maxsize_s = 'Server "upload_max_filesize" not available'; 
        $maxsize = 5242880; 
    } else { 
        $maxsize_s = SYS_MAX_FILESIZE; 
        if (return_bytes(SYS_MAX_FILESIZE)<5242880 && SYS_MAX_FILESIZE!=-1) 
            $maxsize = (return_bytes(SYS_MAX_FILESIZE)-20000); 
        else 
            $maxsize = 5242880; 
    }	
            
    if (!SYS_MAX_INPUT_TIME) { 
        $maxtime_s = 'Server "max_input_time" not available'; 
    } else { 
        if (SYS_MAX_INPUT_TIME!=-1) 
            $maxtime_s = SYS_MAX_INPUT_TIME.'s'; 
        else 
            $maxtime_s = 'unlimited'; 
    }
    
    if (!SYS_MAX_POST_SIZE) { 
        $maxpost_s = 'Server "max_post_size" not available'; 
    } else { 
        if (SYS_MAX_POST_SIZE!=-1) 
            $maxpost_s = SYS_MAX_POST_SIZE; 
        else 
            $maxpost_s = 'unlimited'; 
    }
            
    if (!SYS_MAX_INPUT_VARS && !SYS_MAX_UPLOADS && SYS_MAX_INPUT_VARS>0) { 
        $maxinput_s = 'Server "max_input_time" not available'; 
        $maxinput=5; 
    } else { 
        $maxinput_s = SYS_MAX_INPUT_VARS-$maxfiles-4; 
        $maxinput=5; 
    }
        
    //check php suitable version:
    $php_check = array_map('intval', explode('.', $php_version));
    if($php_check[0]>=5 && $php_check[1]>=3) 
        $php_check_icon = "<img src='installation/yes.png' class='help_expand' />"; 
    else $php_check_icon = "<img src='installation/no.png' class='help_expand' />";
        
    //enable button:
    if(!$flag_func 
        || $php_check_icon=="<img src='installation/no.png' class='help_expand' />"
        ||FILE_UPLOADS!='YES'
    ) { 
        $disable = 'DISABLED'; 
    } else { 
        $disable = $disable = ""; 
    }

    //Html help content:		
    $help1 = "PHP vesrion should be older then 5.3 .";
    $help2 = "MySQL version should be older then 4 .";
    $help3 = "Server Should allow files upload.";
    $help4 = "Checks that the required PHP functions are enabled on your server. ";
    if (!$flag_func) 
        $help4.= $functions_to_turn_on;
    $help5 = "You need to specify the MySQL server IP or set it to \"loclahost\".";
    $help6 = "Database name is the name (with prefix if needed) of the DB you cre".
             "ated for the installation, this is the only thing you should set ou".
             "tside the installation script. You can set any name you want, connec".
             "tion to the database will be tested by the installation. ";
    $help7 = "You need to specify the MySQL server User-Name of the database you".
             "created.";
    $help8 = "You need to specify the MySQL server User-Password of the database".
             "you created.";
    $help9 = "File Folder is the absolute path to the \"files\" directory who".
             "will contain all the uploaded files. this default path is the abs".
             "olute path to the default folder on you server. If you didn't modi".
             "fied it don't change the path.";
    $help10 = "Brand name can be your company name or oragnization - you must se".
              "t it, if you are not sure set it to \"TakeThat\" it can be update".
              "d later via Admin panel. This brand name will also be the sender ".
              "name in all the e-mails that the website will send.";
    $help11 = "This parameter will set the limit of files a user can upload in ".
              "one send operation.";
    $help12 = "This parameter will set the limit of file size (in bytes: 1MB = ".
              "1,048,576 bytes) a user can upload. You should consider the server".
              "restrictions.";
    $help13 = "This parameter will set the limit of recipients a user send to in".
              "one send operation.";
    $help14 = "This parameter will set the administration pannel user name.";
    $help15 = "This parameter will set the administration pannel password.";
    $help16 = "This parameter will validate the adiminstration pannel password.";
    $help17 = "This parameter will set the mail account the program will use. ".
              "This account must be a configured account on the server mail accounts.";
?>
    <table border='0' cellpadding='1px' cellspacing='1px'>
        <tr><td width='160px'>PHP version:</td><td width='177px' class='classtd_explain'><?php echo $php_version; ?></td><td><?php echo $php_check_icon; ?></td></tr>
            <tr><td colspan='3'><div class='erroe_conn' style='display:none;'>Error</div><div class='help_conn' style='display:none;'><?php echo $help1; ?></div></td></tr>
        <tr><td>SQL version:</td><td width='177px' class='classtd_explain'>Will be tested while installing.</td><td><img src='installation/help.png' class='help_expand' /></td></tr>
            <tr><td colspan='3'><div class='erroe_conn' style='display:none;'>Error</div><div class='help_conn' style='display:none;'><?php echo $help2; ?></div></td></tr>
        <tr><td>File Upload:</td><td width='177px' class='classtd_explain'><?php  echo FILE_UPLOADS; ?></td><td><?php if(FILE_UPLOADS=='YES') echo"<img src='installation/yes.png' class='help_expand' />"; else echo"<img src='installation/no.png' class='help_expand' />"; ?></td></tr>
            <tr><td colspan='3'><div class='erroe_conn' style='display:none;'>Error</div><div class='help_conn' style='display:none;'><?php echo $help3; ?></div></td></tr>
        <tr><td>Required functions:</td><td width='177px' class='classtd_explain'><?php echo $inline_mes_func; ?></td><td><?php echo $required_func_icon; ?></td></tr>
            <tr><td colspan='3'><div class='erroe_conn' style='display:none;'>Error</div><div class='help_conn' style='display:none;'><?php echo $help4; ?></div></td></tr>
    </table>
<p class='steps'>Step 1:<em>Server Settings.</em></p>
    <table border='0' cellpadding='1px' cellspacing='1px'>
        <tr><td width='160px' id='er_host' class='remove1'>MySql Host:</td><td width='180px'><input type='text' name='host' value='localhost' /></td><td width='33px'><img src='installation/help.png' class='help_expand' /></td><td width='340px' class='classtd_explain'>Enter your SQL server host address.</td></tr>
            <tr><td colspan='4'><div class='erroe_conn' style='display:none;'>Error</div><div class='help_conn' style='display:none;'><?php echo $help5; ?></div></td></tr>
        <tr><td id='er_dbname' class='remove1'>Database name:</td><td><input type='text' name='db_name'  placeholder='DB name' /></td><td><img src='installation/help.png' class='help_expand' /></td><td class='classtd_explain'>Enter your SQL DataBase name.</td></tr>
            <tr><td colspan='4'><div class='erroe_conn' style='display:none;'>Error</div><div class='help_conn' style='display:none;'><?php echo $help6; ?></div></td></tr>
        <tr><td id='er_dbuser' class='remove1'>Database user name:</td><td><input type='text' name='db_user' placeholder='DB user name' /></td><td><img src='installation/help.png' class='help_expand' /></td><td class='classtd_explain'>Enter your SQL server user name.</td></tr>
            <tr><td colspan='4'><div class='erroe_conn' style='display:none;'>Error</div><div class='help_conn' style='display:none;'><?php echo $help7; ?></div></td></tr>
        <tr><td id='er_dbpass' class='remove1'>Database password:</td><td><input type='text' name='db_pass' placeholder='DB password' /></td><td><img src='installation/help.png' class='help_expand' /></td><td class='classtd_explain'>Enter your SQL server user password.</td></tr>
            <tr><td colspan='4'><div class='erroe_conn' style='display:none;'>Error</div><div class='help_conn' style='display:none;'><?php echo $help8; ?></div></td></tr>
        <tr><td id='er_folder' class='remove1'>Files Folder:</td><td><input type='text' name='files_path' value='<?php echo $filesfolder; ?>' /></td><td><img src='installation/help.png' class='help_expand' /></td><td class='classtd_explain'>Enter the full directory path of the folder who will contain the sent files. </td></tr>
            <tr><td colspan='4'><div class='erroe_conn' style='display:none;'>Error</div><div class='help_conn' style='display:none;'><?php echo $help9; ?></div></td></tr>
    </table>
<p class='steps'>Step 2:<em>General Settings.</em></p>
    <table border='0' cellpadding='1px' cellspacing='1px'>
        <tr><td width='160px' id='er_brand' class='remove1'>Brand name:</td><td width='180px'><input type='text' name='barnd_name' value='TakeThat' /></td><td width='33px'><img src='installation/help.png' class='help_expand' /></td><td width='340px' class='classtd_explain'>Enter your brand name.</td></tr>
            <tr><td colspan='4'><div class='erroe_conn' style='display:none;'>Error</div><div class='help_conn' style='display:none;'><?php echo $help10; ?></div></td></tr>
        <tr><td id='er_maxfile' class='remove1'>Maximum files input:</td><td><input type='text' name='max_files' value='<?php echo $maxfiles; ?>' /></td><td><img src='installation/help.png' class='help_expand' /></td><td class='classtd_explain'>Server limit: <?php echo $maxfiles_s; ?></td></tr>
            <tr><td colspan='4'><div class='erroe_conn' style='display:none;'>Error</div><div class='help_conn' style='display:none;'><?php echo $help11; ?></div></td></tr>
        <tr><td id='er_maxsize' class='remove1'>Maximum file size:</td><td><input type='text' name='max_size' value='<?php echo $maxsize; ?>' /></td><td><img src='installation/help.png' class='help_expand' /></td><td class='classtd_explain'>Server limit: <?php echo $maxsize_s; ?>  -  Server input time limit: <?php echo $maxtime_s; ?>  -  Server Post limit(total): <?php echo $maxpost_s ?></td></tr>
            <tr><td colspan='4'><div class='erroe_conn' style='display:none;'>Error</div><div class='help_conn' style='display:none;'><?php echo $help12; ?></div></td></tr>
        <tr><td id='er_maxrec' class='remove1'>Maximum recipients:</td><td><input type='text' name='max_rec' value='<?php echo $maxinput; ?>' /></td><td><img src='installation/help.png' class='help_expand' /></td><td class='classtd_explain'>Server limit: <?php echo $maxinput_s; ?></td></tr>
            <tr><td colspan='4'><div class='erroe_conn' style='display:none;'>Error</div><div class='help_conn' style='display:none;'><?php echo $help13; ?></div></td></tr>
        <tr><td id='er_user' class='remove1'>Admin User-name:</td><td><input type='text' name='user' value='admin' /></td><td><img src='installation/help.png' class='help_expand' /></td><td class='classtd_explain'>Choose a user name. (min length 5)</td></tr>
            <tr><td colspan='4'><div class='erroe_conn' style='display:none;'>Error</div><div class='help_conn' style='display:none;'><?php echo $help14; ?></div></td></tr>
        <tr><td id='er_pass' class='remove1'>Admin Password:</td><td><input type='password' name='pass' /></td><td><img src='installation/help.png' class='help_expand' /></td><td class='classtd_explain'>Choose a password. (min length 6)</td></tr>
            <tr><td colspan='4'><div class='erroe_conn' style='display:none;'>Error</div><div class='help_conn' style='display:none;'><?php echo $help15; ?></div></td></tr>
        <tr><td id='er_repass' class='remove1'>Re type Password:</td><td><input type='password' name='repass' /></td><td><img src='installation/help.png' class='help_expand' /></td><td class='classtd_explain'>Re type your password please.</td></tr>
            <tr><td colspan='4'><div class='erroe_conn' style='display:none;'>Error</div><div class='help_conn' style='display:none;'><?php echo $help16; ?></div></td></tr>
            
    </table>
<p class='steps'>Step 3:<em>Email Settings.</em></p>
    <table border='0' cellpadding='1px' cellspacing='1px'>
        <tr><td width='160px' id='er_email' class='remove1'>Email account:</td><td width='180px'><input type='text' name='email_account' placeholder='example@domain.com' /></td><td width='33px'><img src='installation/help.png' class='help_expand' /></td><td width='340px' class='classtd_explain'>Enter E-mail account.</td></tr>
            <tr><td colspan='4'><div class='erroe_conn' style='display:none;'>Error</div><div class='help_conn' style='display:none;'><?php echo $help17; ?></div></td></tr>
    </table>
<input type='button' class='run_in' id='run_install' value='&bull;&nbsp;&nbsp;Run Installation&nbsp;&nbsp;&bull;' <?php echo $disable; ?>/>
</form>
</div>
<br />
<br />
<br />
<br />
<br />
<br />
</body>
</html>
<?php
/*FUCTIONS*/
function return_bytes($val) {
    
    if($val==-1 || $val==false) $val = 2000000; //php deafault upload size
    
    $val = trim($val);
    $last = strtolower($val[strlen($val)-1]);
    switch($last) {
        case 'g':
            $val *= 1024;
        case 'm':
            $val *= 1024;
        case 'k':
            $val *= 1024;
    }
    return $val;
}
?>