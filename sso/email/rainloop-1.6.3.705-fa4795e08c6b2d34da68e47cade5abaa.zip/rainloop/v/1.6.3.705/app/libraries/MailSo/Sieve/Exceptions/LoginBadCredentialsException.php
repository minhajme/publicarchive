<?php

namespace MailSo\Sieve\Exceptions;

/**
 * @category MailSo
 * @package Sieve
 * @subpackage Exceptions
 */
class LoginBadCredentialsException extends \MailSo\Sieve\Exceptions\LoginException {}
