<?php

namespace MailSo\Net\Exceptions;

/**
 * @category MailSo
 * @package Net
 * @subpackage Exceptions
 */
class InvalidArgumentException extends \MailSo\Net\Exceptions\Exception {}
