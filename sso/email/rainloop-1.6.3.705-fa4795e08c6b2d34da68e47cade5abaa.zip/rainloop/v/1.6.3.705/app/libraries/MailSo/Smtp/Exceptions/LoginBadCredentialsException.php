<?php

namespace MailSo\Smtp\Exceptions;

/**
 * @category MailSo
 * @package Smtp
 * @subpackage Exceptions
 */
class LoginBadCredentialsException extends \MailSo\Smtp\Exceptions\LoginException {}
