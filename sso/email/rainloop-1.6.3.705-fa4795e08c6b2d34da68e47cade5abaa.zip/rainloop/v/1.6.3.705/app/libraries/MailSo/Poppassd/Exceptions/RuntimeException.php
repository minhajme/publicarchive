<?php

namespace MailSo\Poppassd\Exceptions;

/**
 * @category MailSo
 * @package Poppassd
 * @subpackage Exceptions
 */
class RuntimeException extends \MailSo\Poppassd\Exceptions\Exception {}
