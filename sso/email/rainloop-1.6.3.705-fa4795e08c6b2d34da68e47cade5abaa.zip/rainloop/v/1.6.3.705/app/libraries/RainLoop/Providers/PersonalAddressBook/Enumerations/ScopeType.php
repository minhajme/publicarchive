<?php

namespace RainLoop\Providers\PersonalAddressBook\Enumerations;

class ScopeType
{
	const DEFAULT_ = 0;
	const SHARE_ALL = 2;
}
