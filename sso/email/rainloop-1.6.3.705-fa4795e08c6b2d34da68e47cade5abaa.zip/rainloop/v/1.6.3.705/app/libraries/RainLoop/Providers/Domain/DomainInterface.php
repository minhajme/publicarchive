<?php

namespace RainLoop\Providers\Domain;

interface DomainInterface
{
}