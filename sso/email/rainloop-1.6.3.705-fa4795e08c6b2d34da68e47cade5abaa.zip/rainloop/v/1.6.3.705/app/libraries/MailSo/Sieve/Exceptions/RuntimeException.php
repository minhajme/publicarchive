<?php

namespace MailSo\Sieve\Exceptions;

/**
 * @category MailSo
 * @package Sieve
 * @subpackage Exceptions
 */
class RuntimeException extends \MailSo\Sieve\Exceptions\Exception {}
