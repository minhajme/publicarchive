<?php

namespace MailSo\Mail\Exceptions;

/**
 * @category MailSo
 * @package Mail
 * @subpackage Exceptions
 */
class Exception extends \MailSo\Base\Exceptions\Exception {}
