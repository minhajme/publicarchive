<?php

namespace MailSo\Net\Exceptions;

/**
 * @category MailSo
 * @package Net
 * @subpackage Exceptions
 */
class SocketWriteException extends \MailSo\Net\Exceptions\Exception {}
