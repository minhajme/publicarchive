<?php

namespace MailSo\Net\Exceptions;

/**
 * @category MailSo
 * @package Net
 * @subpackage Exceptions
 */
class Exception extends \MailSo\Base\Exceptions\Exception {}
