<?php

namespace RainLoop\Enumerations;

class InterfaceAnimation
{
	const NONE = 'None';
	const NORMAL = 'Normal';
	const FULL = 'Full';
}