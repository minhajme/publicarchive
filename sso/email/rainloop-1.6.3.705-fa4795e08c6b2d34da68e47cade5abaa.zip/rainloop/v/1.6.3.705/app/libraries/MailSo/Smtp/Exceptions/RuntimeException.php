<?php

namespace MailSo\Smtp\Exceptions;

/**
 * @category MailSo
 * @package Smtp
 * @subpackage Exceptions
 */
class RuntimeException extends \MailSo\Smtp\Exceptions\Exception {}
