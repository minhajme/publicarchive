<?php

namespace RainLoop\Enumerations;

class CustomThemeType
{
	const LIGHT = 'Light';
	const DARK = 'Dark';
}